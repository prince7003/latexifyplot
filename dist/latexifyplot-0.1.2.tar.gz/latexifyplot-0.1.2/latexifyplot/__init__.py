# latexifyplot/__init__.py
from .latexify import latexify
from .format_axes import format_axes